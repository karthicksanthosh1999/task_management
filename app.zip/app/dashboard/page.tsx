export default function Page() {
  return <h1>Welcome to the dashboard</h1>;
}
