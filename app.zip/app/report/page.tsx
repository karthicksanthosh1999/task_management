'use client'
import React from 'react'

const page = () => {
    return (
        <div>
            Welcome to the report page
        </div>
    )
}

export default page
