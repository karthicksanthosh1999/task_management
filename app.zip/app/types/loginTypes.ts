export interface TLoginTypes {
  email: string;
  password: string;
}
