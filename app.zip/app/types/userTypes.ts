export interface IUser {
  id?: string;
  name: string;
  email: string;
  mobile: string;
  password: string;
  company: string

  image?: string;
}
